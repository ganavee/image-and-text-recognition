Image-recognition using Tensorflow
